# Audit de testing — Lámina v2.0

**Fecha de la sesión:** 23 de octubre de 2026  
**Versión probada:** v2.0  
**Alcance:** este documento contiene **únicamente hallazgos y evidencias obtenidos durante la sesión de testing de hoy**. No incluye observaciones de versiones o conversaciones anteriores.

## Resumen ejecutivo

Durante la prueba se recorrieron los principales flujos visibles de Lámina v2.0: creación de presentaciones, carga de materiales, revisión matemática, aprobación de contenido, generación y revisión del diseño, perfil, conexión MCP con ChatGPT y preparación para publicación.

Se registraron **14 hallazgos**:

- **7 de prioridad alta**
- **7 de prioridad media**
- **1 punto positivo destacado:** la integración MCP con ChatGPT funcionó correctamente de extremo a extremo

Los problemas más importantes se concentran en cuatro áreas:

1. **Gestión de archivos y recursos:** falta una forma clara de eliminar/reemplazar presentaciones, PDFs y logos
2. **Flujo y feedback:** algunas acciones importantes quedan fuera de vista y los procesos largos no notifican al terminar
3. **Matemática y renderizado:** varias expresiones LaTeX aparecen como texto crudo o provocan problemas de layout
4. **Corrección/publicación:** la autocorrección y el pulido final pueden no resolver los problemas detectados

---

## Matriz de hallazgos

| # | Hallazgo | Tipo | Prioridad |
|---|---|---|---|
| 1 | Falta opción para eliminar presentaciones | UX / mejora | Media |
| 2 | Gestión poco clara de archivos adjuntos | UX | Media |
| 3 | Falta notificación al terminar investigación/redacción | UX | Media |
| 4 | Información de verificación redundante | UX | Media |
| 5 | Corregir fórmulas obliga a editar LaTeX | UX | Alta |
| 6 | La siguiente acción queda fuera de vista tras aprobar | UX / flujo | Alta |
| 7 | Falta notificación al terminar el diseño final | UX | Media |
| 8 | No hay forma clara de eliminar o reemplazar el logo | UX | Media |
| 9 | Generación de diseño excesivamente lenta y sin feedback suficiente | Funcional / feedback | Alta |
| 10 | Matrices aparecen como LaTeX crudo dentro de tablas | Renderizado | Alta |
| 11 | El diseño final rompe o superpone contenido matemático | Renderizado / layout | Alta |
| 12 | “Corregir automáticamente” no resuelve el error detectado | Funcional | Alta |
| 13 | El pulido final obligatorio puede bloquear la publicación y no garantiza mejoras | UX / flujo | Alta |
| 14 | No se muestra el uso de la cuota ni cuánto queda disponible | UX / transparencia | Media |

---

# Hallazgos

## 1. Falta una opción para eliminar presentaciones

**Tipo:** Mejora de UX  
**Prioridad:** Media

En el dashboard no aparece una opción visible para eliminar una presentación. Esto puede resultar incómodo cuando se crean presentaciones de prueba, duplicadas o que ya no se necesitan.

### Propuesta de mejora

Añadir un menú de tres puntos en cada tarjeta con opciones como:

- Renombrar
- Duplicar
- Eliminar

Al seleccionar **Eliminar**, debería mostrarse una confirmación para evitar borrados accidentales. También sería útil una papelera o una opción de deshacer durante unos segundos.

### Evidencia

![Dashboard sin opción visible para eliminar presentaciones](evidencias/01_dashboard_sin_eliminar_presentacion.png)

---

## 2. No hay una forma clara de eliminar o reemplazar archivos adjuntos

**Tipo:** Problema de UX  
**Prioridad:** Media

Después de subir un PDF, la interfaz muestra el nombre del archivo dentro del selector, pero no ofrece controles claros para eliminarlo, reemplazarlo o gestionar varios archivos.

La interfaz indica que se pueden subir hasta 3 archivos, pero no presenta una lista visual de adjuntos ya cargados.

### Casos afectados

- Seleccionar el PDF equivocado
- Sustituir un PDF por otro
- Eliminar un archivo antes de continuar
- Gestionar el máximo de 3 archivos

### Propuesta de mejora

Mostrar una lista de adjuntos después de seleccionarlos:

```text
Clase 2 matrices.pdf      [Eliminar]
Ejercicios matrices.pdf   [Eliminar]
Apuntes.docx              [Eliminar]
```

Además, incorporar un botón **“Añadir otro archivo”** hasta alcanzar el máximo permitido.

### Evidencia

![PDF seleccionado sin controles claros para eliminarlo o reemplazarlo](evidencias/02_archivo_pdf_sin_gestion.png)

---

## 3. Falta una notificación cuando termina la investigación y redacción

**Tipo:** Mejora de UX  
**Prioridad:** Media

Durante la generación inicial, Lámina indica que el usuario puede cerrar la página y volver después. Sin embargo, si el usuario cambia de pestaña o continúa con otra tarea, no existe una señal clara de que el proceso haya terminado.

### Propuesta de mejora

Enviar una notificación cuando el borrador esté listo:

> Tu presentación “Definición, clasificación y operaciones con matrices” está lista para revisar.

Podría implementarse como:

- Notificación del navegador
- Aviso interno de Lámina
- Badge en “Presentaciones”
- Cambio de estado visible en el dashboard
- Enlace directo a la presentación terminada

### Evidencia

![Proceso de investigación y redacción sin mecanismo de notificación al finalizar](evidencias/03_generacion_contenido_sin_notificacion.png)

---

## 4. La información de verificación se muestra dos veces

**Tipo:** Mejora de UX  
**Prioridad:** Media

La nueva sección **“Avisos de verificación”** está bien planteada: concentra los elementos pendientes, renderiza la fórmula y permite **“Sí, aprobar”** o **“No, corregir”**.

Sin embargo, la misma incidencia vuelve a aparecer dentro del editor de cada diapositiva como:

- Badge `1 por revisar`
- Mensaje técnico completo
- LaTeX crudo
- Motivo de la verificación

Esto duplica información y añade ruido visual.

### Propuesta de mejora

Mantener dentro de cada bloque únicamente un indicador contextual:

```text
⚠ 1 por revisar   [Revisar]
```

La explicación completa, la fórmula renderizada y las acciones de aprobar/corregir deberían permanecer en **Avisos de verificación**.

### Evidencia

**Tarjeta central de revisión:**

![Tarjeta de verificación](evidencias/04_tarjeta_verificacion.png)

**Misma incidencia repetida dentro del editor:**

![Editor repitiendo la verificación](evidencias/04_editor_repite_verificacion.png)

---

## 5. Corregir una fórmula requiere editar código LaTeX

**Tipo:** Problema de UX  
**Prioridad:** Alta

Cuando el usuario selecciona **“No, corregir”**, la interfaz muestra un campo editable con la fórmula en formato LaTeX.

Ejemplo:

```text
A = \begin{pmatrix} ... \end{pmatrix}
```

No se puede asumir que el usuario final —por ejemplo, un docente— conozca LaTeX.

### Impacto

El usuario puede:

- No saber qué parte modificar
- Romper accidentalmente la sintaxis
- Evitar la corrección por miedo a dañarla
- Tener que aprender una notación técnica ajena a su tarea

### Propuesta de mejora

Ofrecer un editor visual como modo principal:

- Matrices
- Fracciones
- Potencias
- Raíces
- Sumatorias
- Edición directa de celdas

También podría incluirse una alternativa en lenguaje natural:

> Cambia `a12` por `a13`

El LaTeX podría conservarse como **modo avanzado**, pero no como única forma de corrección.

### Evidencia

![Corrección de fórmula mediante LaTeX](evidencias/05_correccion_formula_latex.png)

---

## 6. Después de aprobar el contenido, la siguiente acción queda demasiado abajo

**Tipo:** Problema de UX / flujo  
**Prioridad:** Alta

Después de aprobar el contenido, la interfaz muestra correctamente **“Contenido aprobado”**, pero el botón **“Generar el diseño”** se encuentra al final de una página muy larga.

Desde la parte superior, el usuario puede pensar que no ocurrió nada o no saber cuál es el siguiente paso.

### Impacto

- Puede parecer que el botón de aprobar no funcionó
- La continuidad del flujo no es evidente
- El usuario debe recorrer toda la página para descubrir cómo continuar

### Propuesta de mejora

Después de aprobar:

- Hacer scroll automático a la siguiente acción
- Mostrar un CTA inmediato: **“Continuar al diseño”**
- Usar una barra sticky inferior
- Convertir el paso **Diseño** del indicador superior en una acción clara

### Evidencia

**Estado aprobado en la parte superior:**

![Contenido aprobado](evidencias/06_contenido_aprobado_arriba.png)

**Acción para continuar ubicada al final:**

![Botón generar diseño al final de la página](evidencias/06_generar_diseno_abajo.png)

---

## 7. Falta una notificación cuando termina el diseño final

**Tipo:** Mejora de UX  
**Prioridad:** Media

Durante la etapa **“Diseñando las diapositivas…”**, la propia interfaz indica que el proceso suele tardar varios minutos.

Si el usuario cambia de pestaña o minimiza el navegador, no tiene una forma clara de saber cuándo terminó.

### Propuesta de mejora

Notificar cuando el diseño esté listo:

> Tu presentación ya está lista.

Opciones:

- Notificación del navegador
- Aviso dentro de Lámina
- Badge en Presentaciones
- Cambio visible del estado
- Enlace directo para abrir la presentación final

### Evidencia

![Diseño en proceso](evidencias/07_diseno_en_proceso.png)

---

## 8. No hay una forma clara de eliminar o reemplazar el logo personal

**Tipo:** Problema de UX  
**Prioridad:** Media

En **Mi cuenta**, el usuario puede subir un logo personal, pero no aparecen controles claros para:

- Eliminarlo
- Reemplazarlo
- Previsualizarlo
- Deshacer la selección antes de guardar

Es el mismo patrón observado en la gestión de PDFs.

### Propuesta de mejora

Después de seleccionar un logo:

```text
logo-personal.png   [Reemplazar] [Eliminar]
```

También sería útil mostrar una vista previa y dejar claro qué logo se usará si no existe uno personal.

### Evidencia

![Selector de logo personal sin controles de gestión](evidencias/08_logo_personal_sin_gestion.png)

---

## 9. La generación del diseño puede tardar mucho más de lo indicado sin feedback suficiente

**Tipo:** Problema funcional / feedback  
**Prioridad:** Alta

Lámina indicaba que el proceso de diseño suele tardar **entre 2 y 6 minutos**.

Durante la prueba, la generación permaneció activa durante aproximadamente **14 minutos** sin terminar y sin mostrar un mensaje de demora, error o acción alternativa.

En DevTools también apareció una respuesta HTTP `401 Unauthorized`. Con la evidencia disponible **no se puede afirmar que ese 401 haya sido la causa del retraso**.

El proceso finalmente sí terminó, por lo que el hallazgo no es “no genera”, sino **tiempo de generación excesivo y manejo insuficiente de una espera anormal**.

### Propuesta de mejora

Si el proceso supera un umbral razonable:

- Mostrar: **“Está tardando más de lo esperado”**
- Permitir reintentar
- Permitir cancelar
- Informar si existe un error del servidor o autenticación
- Evitar dejar indefinidamente el estado “Diseñando…”

### Evidencia

![Generación superando ampliamente el tiempo esperado y 401 visible en consola](evidencias/09_generacion_14_minutos_401.png)

---

## 10. Las matrices aparecen como código LaTeX dentro de las tablas

**Tipo:** Bug de renderizado  
**Prioridad:** Alta

En la diapositiva **“Dimensiones de una matriz”**, las matrices incluidas dentro de una tabla aparecen como texto crudo:

```text
\begin{pmatrix}1&3\\4&2\end{pmatrix}
```

en lugar de renderizarse como matrices.

### Comportamiento esperado

Las celdas que contienen matemáticas deberían renderizar correctamente el contenido.

Si el componente de tabla no admite matemáticas, Lámina debería utilizar un componente alternativo en lugar de mostrar LaTeX sin procesar.

### Impacto

- Reduce legibilidad
- Hace que la presentación parezca inacabada
- Obliga al usuario a corregir una diapositiva generada automáticamente

### Evidencia

![Matrices mostradas como LaTeX crudo en una tabla](evidencias/10_latex_en_tabla.png)

---

## 11. El diseño final rompe parte del contenido matemático

**Tipo:** Bug de renderizado / layout  
**Prioridad:** Alta

Se observaron varios problemas de renderizado y maquetación en las diapositivas finales.

### Problema A — Matemática inline sin renderizar

Aparecen expresiones como:

```text
m\times n
(A\pm B)...
\alpha
\cdot
```

directamente dentro del texto.

![LaTeX inline visible en suma y resta](evidencias/11_latex_inline_suma_resta.png)

### Problema B — El encabezado invade el contenido

En **“Suma y resta de matrices (cont.)”**, el título se superpone con parte del ejercicio.

![Título superpuesto con contenido matemático](evidencias/11_layout_superpuesto.png)

### Problema C — Contenido matemático incompleto o mal ajustado

En **“Multiplicación por escalar”**, la explicación contiene LaTeX visible y el ejemplo queda demasiado ajustado o incompleto.

![Problemas de render y ajuste en multiplicación por escalar](evidencias/11_latex_inline_escalar.png)

### Propuesta de mejora

- Renderizar matemáticas inline dentro de bloques de texto
- Reservar espacio fijo para encabezados
- Revalidar cada layout después del render
- Dividir automáticamente contenido largo en más diapositivas
- No permitir que bloques se solapen o salgan del viewport

---

## 12. “Corregir automáticamente” no corrige el error detectado

**Tipo:** Bug funcional  
**Prioridad:** Alta

Lámina detecta correctamente que una diapositiva tiene contenido que se sale del área visible y ofrece:

- Ver dónde está
- Corregir automáticamente
- Ignorar

Durante la prueba, al seleccionar **“Corregir automáticamente”**, el problema visual permaneció.

### Comportamiento esperado

Después de la autocorrección, Lámina debería:

1. Ajustar el layout
2. Volver a renderizar
3. Revalidar la diapositiva
4. Eliminar el aviso si quedó resuelto

Si no puede solucionarlo, debería mostrar:

> No fue posible corregir automáticamente esta diapositiva. Se requiere edición manual.

### Evidencia

**Error detectado y opción de autocorrección:**

![Error detectado con botón Corregir automáticamente](evidencias/12_error_detectado_y_autocorreccion.png)

**Diapositiva que continúa presentando problemas:**

![Resultado con problema visual](evidencias/12_resultado_con_error.png)

---

## 13. El pulido final obligatorio puede impedir publicar y no garantiza mejoras

**Tipo:** Problema de UX / flujo de publicación  
**Prioridad:** Alta

Antes de publicar, Lámina obliga al usuario a ejecutar un **pulido final**.

Durante la prueba, ese pulido no produjo una mejora visible: los problemas de renderizado y layout observados anteriormente permanecieron.

### Problemas

- El pulido es obligatorio para avanzar hacia publicación
- Puede depender de tokens, cuota de IA u otros recursos limitados
- El usuario podría quedarse bloqueado justo al final del flujo
- Añade tiempo y consumo sin garantizar una mejora
- Los errores previamente detectados pueden continuar iguales

### Escenario de riesgo

Un usuario podría:

1. Crear la presentación
2. Revisar y aprobar contenido
3. Generar diseño
4. Corregir manualmente problemas
5. Llegar a publicación
6. Quedarse bloqueado por falta de recursos para un pulido obligatorio

### Propuesta de mejora

Hacer el pulido opcional:

```text
[Pulir con IA antes de publicar]
[Publicar como está]
```

Si existen errores:

> Esta presentación todavía tiene problemas de diseño. Puedes intentar corregirlos o publicar bajo tu responsabilidad.

Si el pulido se ejecuta, Lámina debería comparar el estado antes y después y mostrar **qué problemas corrigió realmente**.

### Evidencia

No se tomó una captura dedicada exclusivamente al paso de pulido final. El resultado posterior conservó los problemas visuales documentados en los hallazgos 10–12.

---


## 14. No se muestra el uso de la cuota ni cuánto queda disponible

**Tipo:** Problema de UX / transparencia  
**Prioridad:** Media

Durante la prueba no se encontró una sección visible que indique cuánto uso ha consumido el usuario ni cuánto de su cuota o límite todavía tiene disponible.

Esto es especialmente relevante porque algunas acciones de Lámina dependen de generación con IA y pueden consumir recursos, tokens o una cuota limitada.

### Impacto

El usuario no puede saber con claridad:

- cuánto ha consumido
- cuánto le queda disponible
- qué acciones consumen cuota
- si tiene recursos suficientes antes de iniciar una generación
- cuándo se renovará su límite, si existe un período de renovación

Esto puede generar incertidumbre, especialmente antes de procesos largos o pasos obligatorios como generación, regeneración o pulido final.

### Propuesta de mejora

Añadir una sección visible en **Mi cuenta** o en el menú lateral con información como:

```text
Uso del período
Generaciones: 7 / 20
Restantes: 13
Renovación: 1 nov 2026
```

Si el sistema utiliza tokens u otra unidad, también podría mostrarse:

```text
Cuota utilizada: 65 %
Disponible: 35 %
```

Además, antes de ejecutar una acción que consuma cuota, sería útil indicar su posible impacto o advertir cuando el usuario esté cerca del límite.

### Evidencia

No se tomó una captura dedicada exclusivamente a este punto. Durante la navegación por **Mi cuenta**, creación, generación, regeneración y publicación no se encontró un indicador visible del consumo ni de la cuota restante.

---

# Punto positivo destacado

## Integración MCP con ChatGPT funcionando correctamente

**Tipo:** Punto positivo  
**Estado:** Funcionando

Se probó la conexión de Lámina con ChatGPT mediante MCP desde una conversación independiente.

La prueba confirmó que ChatGPT pudo:

- Acceder a Lámina mediante MCP
- Crear una presentación nueva
- Generar el borrador inicial
- Enviar el contenido a Lámina
- Hacer que aparezca en el dashboard como **“Desde tu IA”**
- Integrarse con el flujo normal de revisión de contenido

### Evidencia

**ChatGPT usando la conexión para crear la presentación:**

![ChatGPT creando la presentación mediante MCP](evidencias/positivo_mcp_chatgpt_proceso.png)

**Presentación identificada como “Desde tu IA”:**

![Presentación creada desde ChatGPT](evidencias/positivo_mcp_desde_tu_ia.png)

**Contenido recibido por Lámina y listo para revisión:**

![Presentación creada por MCP dentro de Lámina](evidencias/positivo_mcp_revision_lamina.png)

### Resultado

La integración MCP es uno de los puntos más sólidos de la v2.0 observados durante esta sesión: la funcionalidad no solo aparece en la interfaz, sino que **funcionó de extremo a extremo**.

---

# Recomendaciones priorizadas

## Prioridad alta

1. Corregir el renderizado matemático dentro de tablas y texto inline
2. Evitar superposiciones y contenido fuera del viewport
3. Hacer que **“Corregir automáticamente”** valide que realmente solucionó el problema
4. Permitir publicar sin obligar a ejecutar un pulido final
5. Ofrecer un editor matemático visual en lugar de exigir LaTeX
6. Mejorar el manejo de procesos que exceden el tiempo esperado
7. Hacer evidente el siguiente paso después de aprobar contenido

## Prioridad media

1. Añadir gestión consistente de archivos: eliminar, reemplazar y previsualizar
2. Añadir eliminación de presentaciones
3. Añadir notificaciones al terminar procesos largos
4. Reducir la duplicación de avisos de verificación
5. Mostrar claramente el consumo, la cuota restante y su fecha de renovación

---

# Conclusión

Lámina v2.0 muestra avances importantes en organización, revisión matemática e integración con IA externa. La conexión MCP con ChatGPT funcionó correctamente y el nuevo sistema de tarjetas de verificación resulta mucho más claro para revisar fórmulas.

Los principales problemas detectados están en la **última milla del flujo**: renderizado matemático, maquetación, autocorrección, tiempos de generación, publicación final y transparencia sobre el uso de la cuota.

La prioridad debería ser asegurar que una presentación que ya pasó por revisión pueda llegar al estado final **sin LaTeX visible, sin elementos superpuestos, sin correcciones automáticas inefectivas y sin pasos obligatorios que puedan bloquear la publicación**.
